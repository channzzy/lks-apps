package com.example.lksapps.Model;

public class DataModel {
    private int id;
    private String nama_barang;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama_barang() {
        return nama_barang;
    }

    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    public String getHarga_item() {
        return harga_item;
    }

    public void setHarga_item(String harga_item) {
        this.harga_item = harga_item;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    private String harga_item;
    private String rating;
    private String gambar;

}
