package com.example.lksapps.Model;

import java.util.List;

public class RetrieveResponse {
    private List<DataModel> data;

    public List<DataModel> getData() {
        return data;
    }

    public void setData(List<DataModel> data) {
        this.data = data;
    }
}
