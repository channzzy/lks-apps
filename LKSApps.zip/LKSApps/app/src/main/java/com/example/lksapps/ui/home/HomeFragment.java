package com.example.lksapps.ui.home;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lksapps.API.APIRequestData;
import com.example.lksapps.API.RetroServer;
import com.example.lksapps.Adapter.AdapterData;
import com.example.lksapps.Model.DataModel;
import com.example.lksapps.Model.RetrieveResponse;
import com.example.lksapps.R;
import com.example.lksapps.databinding.FragmentHomeBinding;
import com.example.lksapps.ui.dashboard.DashboardViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.Inflater;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class HomeFragment extends Fragment {
    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private RecyclerView rvData;
    private RecyclerView.Adapter adData;
    private RecyclerView.LayoutManager lmData;

    private TextView totalharga;

    private List<DataModel> listData = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        rvData = root.findViewById(R.id.rv_data);

        lmData = new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false);
        rvData.setLayoutManager(lmData);
        retrievebrg();
        EditText search = root.findViewById(R.id.te_search);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String keyword = charSequence.toString();
                List<DataModel> filteredlist = new ArrayList<>();
                if(keyword.isEmpty()){
                    filteredlist = listData;
                }else {
                    for (DataModel data : listData){
                        if(data.getNama_barang().toLowerCase().contains(keyword.toLowerCase())){
                            filteredlist.add(data);
                        }
                    }
                }
                adData = new AdapterData(getActivity(), filteredlist);
                rvData.setAdapter(adData);
                adData.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        return root;
    }
    public void retrievebrg(){
        APIRequestData ardData = RetroServer.conRetro().create(APIRequestData.class);
        Call<RetrieveResponse> ambil = ardData.retrieveData();

        ambil.enqueue(new Callback<RetrieveResponse>() {
            @Override
            public void onResponse(Call<RetrieveResponse> call, Response<RetrieveResponse> response) {
                listData = response.body().getData();
                adData = new AdapterData(getActivity(), listData);
                rvData.setAdapter(adData);
                adData.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<RetrieveResponse> call, Throwable t) {

            }
        });
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}